# LOLCODE interpreter
## Contributors
- Lucero, Matthew Jason
- Mabaga, Apraem Cayle
- Dolendo, Jericho Paolo

## Requirements
 - To run the program, Python3 must be installed in the device.
 - Tkinter is also necessary to run the GUI.

## Running the program
- The current working directory must contain all python files needed.
- Run the program by typing in the command `python main.py`
- The program will display a GUI and can edit/open .lol files.

